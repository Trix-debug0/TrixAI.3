# Trix AI

Trix AI is a voice-first Android accessibility assistant for blind and visually impaired users.

## Build with GitHub Actions

1. Put all repository files at the repository root.
2. Open **Actions**.
3. Select **Build Trix AI APK**.
4. Select **Run workflow**.
5. Download the **Trix-AI-debug-apk** artifact after the build succeeds.

## Gemini

The prototype accepts a Gemini API key at runtime. Do not commit a real API key to GitHub. For production, use a backend/proxy and restrict/rotate the key.
